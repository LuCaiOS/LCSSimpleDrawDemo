//
//  LCSDrawCustomView.h
//  DrawBoardDemo
//
//  Created by 逯常松 on 2019/9/18.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LCSDrawCustomView : UIView

/*清屏*/
- (void)clearScreen;

/*撤销*/
- (void)revokeScreen;

/*设置画笔的颜色*/
- (void)setStrokeColor:(UIColor *)lineColor;

/*设置画笔的大小*/
- (void)setStrokeWidth:(CGFloat)lineWidth;

/*设置橡皮擦*/
- (void)setStrokeEaser:(BOOL)isEaser;

@end

NS_ASSUME_NONNULL_END
