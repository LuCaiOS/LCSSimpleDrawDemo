//
//  main.m
//  LCSSimpleDrawDemo
//
//  Created by 逯常松 on 2019/10/10.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
