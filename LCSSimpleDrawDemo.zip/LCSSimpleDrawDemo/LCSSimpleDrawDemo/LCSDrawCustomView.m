//
//  LCSDrawCustomView.m
//  DrawBoardDemo
//
//  Created by 逯常松 on 2019/9/18.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import "LCSDrawCustomView.h"
#import "LCSStroke.h"

@interface LCSDrawCustomView(){
    CGMutablePathRef currentPath;//当前路径
}

@property (nonatomic, assign) BOOL isEaser;
//存储所有的路径
@property (nonatomic, strong) NSMutableArray *stroks;
//画笔颜色
@property (nonatomic, strong) UIColor *lineColor;
//画笔粗细
@property (nonatomic, assign) CGFloat lineWidth;

@property (nonatomic, strong) LCSStroke *stroke;

@end

@implementation LCSDrawCustomView

//init func background must be clearcolor
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        _stroks = [[NSMutableArray alloc] initWithCapacity:1];
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    currentPath = CGPathCreateMutable();
    LCSStroke *stroke = [[LCSStroke alloc] init];
    stroke.path = currentPath;
    stroke.blendMode = kCGBlendModeNormal;
    stroke.strokeWidth = _lineWidth;
    stroke.lineColor =  _lineColor;
    stroke.strokeAlpha = 0.5;
    stroke.orignalPoint = point;
    
    _stroke = stroke;
    [_stroks addObject:stroke];
    
    CGPathMoveToPoint(currentPath, NULL, point.x, point.y);
        
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    if(!_isEaser){//简单的绘画
        CGPathAddLineToPoint(currentPath,  &CGAffineTransformIdentity, point.x, point.y);
        
    }else{//橡皮
        for (LCSStroke *stoke in _stroks) {
            
            if(CGPathContainsPoint(stoke.path, NULL, point, FALSE)){//碰撞检测
                [_stroks removeObject:stoke];
                break;
            }
        }
    }
    
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect{
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    for (LCSStroke *stoke in _stroks) {
        [stoke strokeWithContext:context];
    }
    
}


//clear the array
- (void)clearScreen{
    
    _isEaser = NO;
    [_stroks removeAllObjects];
    [self setNeedsDisplay];
}

-(void)revokeScreen{
    _isEaser = NO;
    [_stroks removeLastObject];
    [self setNeedsDisplay];
}


- (void)setStrokeColor:(UIColor *)lineColor{
     _isEaser = NO;
    self.lineColor = lineColor;
}

- (void)setStrokeWidth:(CGFloat)lineWidth{
     _isEaser = NO;
    self.lineWidth = lineWidth;
}

- (void)setStrokeEaser:(BOOL)isEaser{
    _isEaser = isEaser;
}

- (void)dealloc{
    CGPathRelease(currentPath);
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
