//
//  LCSStroke.h
//  DrawBoardDemo
//
//  Created by 逯常松 on 2019/9/18.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
#pragma store CGContextRef info
//可变的路径
typedef struct CGPath *CGMutablePathRef;
//默认的模式。前景图会覆盖背景图
typedef enum CGBlendMode CGBlendMode;

@interface LCSStroke : NSObject

@property (nonatomic) CGMutablePathRef path;

@property (nonatomic, assign) CGBlendMode blendMode;
//宽度
@property (nonatomic, assign) CGFloat strokeWidth;
//线的颜色
@property (nonatomic, strong) UIColor *lineColor;
//开始点
@property (nonatomic, assign) CGPoint orignalPoint;
//结束点
@property (nonatomic, assign) CGPoint endPoint;
//颜色的透明度
@property (nonatomic, assign) CGFloat strokeAlpha;
//绘制
- (void)strokeWithContext:(CGContextRef)context;

@end

NS_ASSUME_NONNULL_END
