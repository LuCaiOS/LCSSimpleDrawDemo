//
//  LCSClassroomSketchpadToolView.m
//  YNStudentSideOnLine
//
//  Created by 逯常松 on 2019/10/10.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import "LCSClassroomSketchpadToolView.h"

#define ButtonSelectedBackGroundColor  RGB(50, 51, 56)

@interface LCSClassroomSketchpadToolView()

@property (nonatomic, strong) UIView *topBackgroundView;

@property (nonatomic, strong) UIView *bottomBackView;

@property (nonatomic, strong) UIButton *penBtn;

@property (nonatomic, assign) BOOL penBtnSelected;

@property (nonatomic, strong) UIButton *eraserBtn;

@property (nonatomic, strong) UIButton *cleanBtn;

@property (nonatomic, strong) UIButton *colorBtn;

@property (nonatomic, strong) UIView *currentColorBackView;

@property (nonatomic, strong) UIView *currentColorView;

@end

@implementation LCSClassroomSketchpadToolView

- (instancetype)init{
    if(self = [super init]){
        self.backgroundColor = [UIColor greenColor];
        self.colorViewColor = [UIColor grayColor];
        _colorOfBtnIndex = 1;
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    self.topBackgroundView.frame = CGRectMake(0, 0, 50, 150);
    self.bottomBackView.frame = CGRectMake(0, self.topBackgroundView.frame.origin.y+self.topBackgroundView.frame.size.height+10, 50, 100);
    self.penBtn.frame = CGRectMake(5, 5, 40, 40);
    self.eraserBtn.frame = CGRectMake(5, self.penBtn.frame.origin.y+self.penBtn.frame.size.height+10, 40, 40);
    self.cleanBtn.frame = CGRectMake(5, self.eraserBtn.frame.origin.y+self.eraserBtn.frame.size.height+10, 40, 40);
    self.colorBtn.frame = CGRectMake(5, 5, 40, 40);
    self.currentColorBackView.frame = CGRectMake(5, self.colorBtn.frame.origin.y+self.colorBtn.frame.size.height+10, 40, 40);
    self.currentColorView.frame = CGRectMake(10, 10, 20, 20);
    
}
//setter
- (void)setColorViewColor:(UIColor *)colorViewColor{
    _colorViewColor = colorViewColor;
    [self setColorBtnNormalState:YES];
    self.currentColorView.backgroundColor = colorViewColor;
}

- (void)setColorOfBtnIndex:(int)colorOfBtnIndex{
    _colorOfBtnIndex = colorOfBtnIndex;
}

//click func
- (void)clickPenBtn {
    if (!self.penBtnSelected) {
        self.penBtnSelected = YES;
        if([self.delegate respondsToSelector:@selector(didClickLCSClassroomSketchpadToolView:withButtonIndex:)]){
            [self.delegate didClickLCSClassroomSketchpadToolView:self withButtonIndex:0];
        }
    }else {
        if([self.delegate respondsToSelector:@selector(didClickLCSClassroomSketchpadToolView:withButtonIndex:)]){
            [self.delegate didClickLCSClassroomSketchpadToolView:self withButtonIndex:-1];
        }
    }
    self.penBtn.backgroundColor = [UIColor whiteColor];
    self.eraserBtn.backgroundColor = [UIColor clearColor];
}

- (void)clickEraserBtn{
    self.penBtnSelected = NO;
    self.eraserBtn.backgroundColor = [UIColor whiteColor];
    self.penBtn.backgroundColor = [UIColor clearColor];
    if([self.delegate respondsToSelector:@selector(didClickLCSClassroomSketchpadToolView:withButtonIndex:)]){
        [self.delegate didClickLCSClassroomSketchpadToolView:self withButtonIndex:1];
    }
}

- (void)clickCleanBtn{
    if([self.delegate respondsToSelector:@selector(didClickLCSClassroomSketchpadToolView:withButtonIndex:)]){
        [self.delegate didClickLCSClassroomSketchpadToolView:self withButtonIndex:2];
    }
}

- (void)clickColorBtn{
    [self setColorBtnNormalState:NO];
    if([self.delegate respondsToSelector:@selector(didClickLCSClassroomSketchpadToolView:withButtonIndex:)]){
        [self.delegate didClickLCSClassroomSketchpadToolView:self withButtonIndex:3];
    }
}

//setcolor btn state
- (void)setColorBtnNormalState:(BOOL)isNormal{
    if(isNormal){
        self.colorBtn.backgroundColor = [UIColor clearColor];
    } else {
        self.colorBtn.backgroundColor = [UIColor whiteColor];
    }
}

//lazy load

- (UIView *)topBackgroundView{
    if(_topBackgroundView)
        return _topBackgroundView;
    
    UIView *topBackgroundView = [UIView new];
    topBackgroundView.backgroundColor = [UIColor lightGrayColor];
    
    //设置圆角
    topBackgroundView.layer.cornerRadius = 2.0f;
    //设置阴影
    topBackgroundView.layer.shadowColor = [UIColor colorWithWhite:0 alpha:0.5].CGColor;
    topBackgroundView.layer.shadowOffset = CGSizeMake(0,1);
    topBackgroundView.layer.shadowOpacity = 1;
    topBackgroundView.layer.shadowRadius = 2;
    
    [self addSubview:topBackgroundView];
    _topBackgroundView = topBackgroundView;
    
    return topBackgroundView;
}

- (UIView *)bottomBackView{
    if(_bottomBackView)
        return _bottomBackView;
    
    UIView *bottomBackView = [UIView new];
    bottomBackView.backgroundColor = [UIColor darkGrayColor];
    
    //设置圆角
    bottomBackView.layer.cornerRadius = 2.0f;
    //设置阴影
    bottomBackView.layer.shadowColor = [UIColor colorWithWhite:0 alpha:0.5].CGColor;
    bottomBackView.layer.shadowOffset = CGSizeMake(0,1);
    bottomBackView.layer.shadowOpacity = 1;
    bottomBackView.layer.shadowRadius = 2;
    
    [self addSubview:bottomBackView];
    _bottomBackView = bottomBackView;
    
    
    return bottomBackView;
}

- (UIButton *)penBtn{
    if(_penBtn)
        return _penBtn;
    
    UIButton *penBtn = [UIButton new];
    _penBtn = penBtn;
    [self.topBackgroundView addSubview:penBtn];
    penBtn.backgroundColor = [UIColor redColor];
    [penBtn setTitle:@"笔" forState:UIControlStateNormal];
    [penBtn addTarget:self action:@selector(clickPenBtn) forControlEvents:UIControlEventTouchUpInside];
    self.penBtnSelected = YES;
    return penBtn;
}

- (UIButton *)eraserBtn{
    if(_eraserBtn)
        return _eraserBtn;
    
    UIButton *eraserBtn = [UIButton new];
    _eraserBtn = eraserBtn;
    [self.topBackgroundView addSubview:eraserBtn];
    eraserBtn.backgroundColor = [UIColor redColor];
    [eraserBtn setTitle:@"橡皮" forState:UIControlStateNormal];
    [eraserBtn addTarget:self action:@selector(clickEraserBtn) forControlEvents:UIControlEventTouchUpInside];
    
    return eraserBtn;
}

- (UIButton *)cleanBtn{
    if(_cleanBtn)
        return _cleanBtn;
    
    UIButton *cleanBtn = [UIButton new];
    _cleanBtn = cleanBtn;
    [self.topBackgroundView addSubview:cleanBtn];
    [cleanBtn setBackgroundColor:[UIColor redColor]];
    [cleanBtn setTitle:@"清屏" forState:UIControlStateNormal];
    [cleanBtn addTarget:self action:@selector(clickCleanBtn) forControlEvents:UIControlEventTouchUpInside];
    
    return cleanBtn;
}

- (UIButton *)colorBtn{
    if(_colorBtn)
        return _colorBtn;
    
    UIButton *colorBtn = [UIButton new];
    _colorBtn = colorBtn;
    [self.bottomBackView addSubview:colorBtn];
    colorBtn.backgroundColor = [UIColor redColor];
    [colorBtn setTitle:@"颜色" forState:UIControlStateNormal];
    [colorBtn addTarget:self action:@selector(clickColorBtn) forControlEvents:UIControlEventTouchUpInside];
    
    return colorBtn;
}

- (UIView *)currentColorBackView{
    if(_currentColorBackView)
        return _currentColorBackView;
    
    UIView *currentColorBackView = [UIView new];
//    currentColorBackView.backgroundColor = RGB(50, 51, 56);
    _currentColorBackView = currentColorBackView;
    
    [self.bottomBackView addSubview:currentColorBackView];

    return currentColorBackView;
}

- (UIView *)currentColorView {
    if(_currentColorView)
        return _currentColorView;
    
    UIView *colorView = [UIView new];
    colorView.clipsToBounds = YES;
    colorView.layer.cornerRadius = 10;
    colorView.layer.borderWidth = 1.0f;
    colorView.layer.borderColor = [UIColor grayColor].CGColor;
    _currentColorView = colorView;
    
    [self.currentColorBackView addSubview:colorView];
    
    return colorView;
}

@end
