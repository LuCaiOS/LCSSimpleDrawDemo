//
//  LCSClassroomSketchpadToolView.h
//  YNStudentSideOnLine
//
//  Created by 逯常松 on 2019/10/10.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class LCSClassroomSketchpadToolView;
@protocol LCSClassroomSketchpadToolViewDelegate <NSObject>

/*
 buttonIndex
 0 pen
 1 eraser
 3 clean
 4 color
 
 */
- (void)didClickLCSClassroomSketchpadToolView:(LCSClassroomSketchpadToolView *)sketchpadToolView withButtonIndex:(int)buttonIndex;

@end

@interface LCSClassroomSketchpadToolView : UIView

@property (nonatomic, weak) id<LCSClassroomSketchpadToolViewDelegate>delegate;

@property (nonatomic, strong) UIColor *colorViewColor;

@property (nonatomic, assign) int colorOfBtnIndex;

- (void)setColorBtnNormalState:(BOOL)isNormal;

@end

NS_ASSUME_NONNULL_END
