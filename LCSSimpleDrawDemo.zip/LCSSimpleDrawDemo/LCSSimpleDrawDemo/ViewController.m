//
//  ViewController.m
//  LCSSimpleDrawDemo
//
//  Created by 逯常松 on 2019/10/10.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import "ViewController.h"
#import "LCSDrawCustomView.h"
#import <WebKit/WebKit.h>
#import "LCSClassroomSketchpadToolView.h"

@interface ViewController ()<LCSClassroomSketchpadToolViewDelegate>

@property (nonatomic, strong) LCSDrawCustomView *drawView;

@property (nonatomic, strong) LCSClassroomSketchpadToolView *toolView;

@end

@implementation ViewController

#pragma mark - life cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    int width = [[UIScreen mainScreen] bounds].size.width;
    int height = [[UIScreen mainScreen] bounds].size.height;
    
    _drawView = [[LCSDrawCustomView alloc] initWithFrame:CGRectMake(0, 0, width, height)];
    _drawView.backgroundColor = [UIColor yellowColor];
    [_drawView setStrokeColor:[UIColor redColor]];
    [_drawView setStrokeWidth:3];
    [self.view addSubview:_drawView];
    
    self.toolView.frame = CGRectMake(width-50, 254, 50, 260);
    
   // [self initSomeParamars];
}

- (LCSClassroomSketchpadToolView *)toolView{
    
    if(!_toolView){
        LCSClassroomSketchpadToolView *sketchpadToolView = [[LCSClassroomSketchpadToolView alloc] init];
           _toolView = sketchpadToolView;
           sketchpadToolView.delegate = self;
           [self.drawView addSubview:sketchpadToolView];
           
    }
        
    
   
    return _toolView;
}


#pragma mark - UITableViewDelegate



#pragma mark - CustomDelegate

- (void)didClickLCSClassroomSketchpadToolView:(LCSClassroomSketchpadToolView *)sketchpadToolView withButtonIndex:(int)buttonIndex{
    
    switch (buttonIndex) {
        case -1://显示画笔配置
            break;
        case 0://点击画笔
            [self.drawView setStrokeEaser:NO];
            break;
        case 1://点击橡皮擦
          //  self.isEraserMode = YES ;
            [self.drawView setStrokeEaser:YES];

            break;
        case 2://点击清除按钮
            //[self clearAllLines] ;
            [self.drawView clearScreen];

            break;
        case 3://选择画笔颜色
            [self.drawView setStrokeColor:[UIColor blueColor]];

            break;
        
        default:
            break;
    }
    
}

#pragma mark - EventResponse



#pragma mark - PrivateMethods

//页面初始化信息
- (void)initSomeParamars{
    
}

#pragma mark - Getters and Setters





- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
}
    
    // Do any additional setup after loading the view.
- (void)clickBlack{
    [_drawView setStrokeColor: [UIColor blackColor]];
}

- (void)clickRed{
    [_drawView setStrokeColor : [UIColor redColor] ];
}

- (void)clickblue{
    [_drawView setStrokeColor:  [UIColor blueColor]];
}

- (void)clickrevoke{
    [_drawView revokeScreen];
}

- (void)clickeaser:(UIButton *)sender{
    
    //使用橡皮擦
    [_drawView setStrokeEaser:YES];
    
}



@end
