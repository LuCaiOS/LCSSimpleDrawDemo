//
//  LCSStroke.m
//  DrawBoardDemo
//
//  Created by 逯常松 on 2019/9/18.
//  Copyright © 2019 逯常松. All rights reserved.
//

#import "LCSStroke.h"

@implementation LCSStroke


- (void)strokeWithContext:(CGContextRef)context{
    
    CGContextSetStrokeColorWithColor(context, [_lineColor CGColor]);
    CGContextSetLineWidth(context, _strokeWidth);
    CGContextSetBlendMode(context, _blendMode);
    CGContextSetAlpha(context, _strokeAlpha);
    CGContextBeginPath(context);
    CGContextAddPath(context, _path);
    CGContextStrokePath(context);
    
}

@end
